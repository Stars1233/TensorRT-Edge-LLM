
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} gemm_ampere_splitk4_fp16_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_gemm_ampere_splitk4_fp16_cuda_init(void **);
void _mlir_gemm_ampere_splitk4_fp16_cuda_load_to_device(void **);
static inline void gemm_ampere_splitk4_fp16_Kernel_Module_Load(gemm_ampere_splitk4_fp16_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_gemm_ampere_splitk4_fp16_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_gemm_ampere_splitk4_fp16_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void gemm_ampere_splitk4_fp16_Kernel_Module_Unload(gemm_ampere_splitk4_fp16_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gemm_ampere_splitk4_fp16_Tensor_mA_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gemm_ampere_splitk4_fp16_Tensor_mB_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gemm_ampere_splitk4_fp16_Tensor_mC_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_gemm_ampere_splitk4_fp16__mlir_ciface_cutlass___call_____main__GemmAmpereSplitKFP16_object_at__Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_gemm_ampere_splitk4_fp16_wrapper(gemm_ampere_splitk4_fp16_Kernel_Module_t *module, gemm_ampere_splitk4_fp16_Tensor_mA_t *mA, gemm_ampere_splitk4_fp16_Tensor_mB_t *mB, gemm_ampere_splitk4_fp16_Tensor_mC_t *mC, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[5] = {
        mA, mB, mC, &stream,
        &ret
    };
    _mlir_gemm_ampere_splitk4_fp16__mlir_ciface_cutlass___call_____main__GemmAmpereSplitKFP16_object_at__Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_Tensorgmemodiv8i64div81_CUstream0x0(args, 5);
    return ret;
}
