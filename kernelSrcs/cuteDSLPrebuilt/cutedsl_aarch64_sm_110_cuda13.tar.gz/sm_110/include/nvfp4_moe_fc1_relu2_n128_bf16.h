
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} nvfp4_moe_fc1_relu2_n128_bf16_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_nvfp4_moe_fc1_relu2_n128_bf16_cuda_init(void **);
void _mlir_nvfp4_moe_fc1_relu2_n128_bf16_cuda_load_to_device(void **);
static inline void nvfp4_moe_fc1_relu2_n128_bf16_Kernel_Module_Load(nvfp4_moe_fc1_relu2_n128_bf16_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_nvfp4_moe_fc1_relu2_n128_bf16_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_nvfp4_moe_fc1_relu2_n128_bf16_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void nvfp4_moe_fc1_relu2_n128_bf16_Kernel_Module_Unload(nvfp4_moe_fc1_relu2_n128_bf16_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_nvfp4_moe_fc1_relu2_n128_bf16__mlir_ciface_cutlass_wrapper_blockscaled_contiguous_grouped_gemm_n_majorBlockScaledContiguousGroupedGemmNMajorKernel_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_P(void **args, int32_t num_args);

static inline int32_t cute_dsl_nvfp4_moe_fc1_relu2_n128_bf16_wrapper(nvfp4_moe_fc1_relu2_n128_bf16_Kernel_Module_t *module, void *a_ptr, void *b_ptr, void *a_sf_ptr, void *b_sf_ptr, void *c_ptr, void *alpha_ptr, void *tile_idx_to_group_idx_ptr, void *tile_idx_to_mn_limit_ptr, void *num_non_exiting_tiles_ptr, int64_t m, int64_t n, int64_t n_out, int64_t k, int64_t l, cudaStream_t stream) {
    int32_t ret;
    void *args[16] = {
        &a_ptr, &b_ptr, &a_sf_ptr, &b_sf_ptr, &c_ptr, &alpha_ptr, &tile_idx_to_group_idx_ptr, &tile_idx_to_mn_limit_ptr, &num_non_exiting_tiles_ptr, &m, &n, &n_out, &k, &l, &stream,
        &ret
    };
    _mlir_nvfp4_moe_fc1_relu2_n128_bf16__mlir_ciface_cutlass_wrapper_blockscaled_contiguous_grouped_gemm_n_majorBlockScaledContiguousGroupedGemmNMajorKernel_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_P(args, 16);
    return ret;
}
