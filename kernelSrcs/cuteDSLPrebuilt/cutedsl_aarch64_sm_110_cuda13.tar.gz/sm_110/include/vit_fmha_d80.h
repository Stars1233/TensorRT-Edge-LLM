
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} vit_fmha_d80_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_vit_fmha_d80_cuda_init(void **);
void _mlir_vit_fmha_d80_cuda_load_to_device(void **);
static inline void vit_fmha_d80_Kernel_Module_Load(vit_fmha_d80_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_vit_fmha_d80_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_vit_fmha_d80_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void vit_fmha_d80_Kernel_Module_Unload(vit_fmha_d80_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} vit_fmha_d80_Tensor_q_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} vit_fmha_d80_Tensor_k_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} vit_fmha_d80_Tensor_v_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} vit_fmha_d80_Tensor_o_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} vit_fmha_d80_Tensor_cu_seqlens_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_vit_fmha_d80__mlir_ciface_cutlass___call_vit_____main__BlackwellFusedMultiHeadAttentionForward_object_at__Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemo1__0161298209(void **args, int32_t num_args);

static inline int32_t cute_dsl_vit_fmha_d80_wrapper(vit_fmha_d80_Kernel_Module_t *module, vit_fmha_d80_Tensor_q_tensor_t *q_tensor, vit_fmha_d80_Tensor_k_tensor_t *k_tensor, vit_fmha_d80_Tensor_v_tensor_t *v_tensor, vit_fmha_d80_Tensor_o_tensor_t *o_tensor, vit_fmha_d80_Tensor_cu_seqlens_t *cu_seqlens, int32_t max_seqlen, float scale_softmax_log2, float scale_softmax, float scale_output, cudaStream_t stream) {
    int32_t ret;
    void *args[11] = {
        q_tensor, k_tensor, v_tensor, o_tensor, cu_seqlens, &max_seqlen, &scale_softmax_log2, &scale_softmax, &scale_output, &stream,
        &ret
    };
    _mlir_vit_fmha_d80__mlir_ciface_cutlass___call_vit_____main__BlackwellFusedMultiHeadAttentionForward_object_at__Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemo1__0161298209(args, 11);
    return ret;
}
